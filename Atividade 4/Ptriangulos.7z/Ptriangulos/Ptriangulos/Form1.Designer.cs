﻿namespace Ptriangulos
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txtValA = new System.Windows.Forms.TextBox();
            this.txtValB = new System.Windows.Forms.TextBox();
            this.txtValC = new System.Windows.Forms.TextBox();
            this.lblValA = new System.Windows.Forms.Label();
            this.lblValB = new System.Windows.Forms.Label();
            this.lblValC = new System.Windows.Forms.Label();
            this.btnExecuta = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.txtType = new System.Windows.Forms.TextBox();
            this.lblTipoTri = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtValA
            // 
            this.txtValA.Location = new System.Drawing.Point(101, 30);
            this.txtValA.Name = "txtValA";
            this.txtValA.Size = new System.Drawing.Size(100, 20);
            this.txtValA.TabIndex = 0;
            this.txtValA.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtValA_KeyPress);
            this.txtValA.Validating += new System.ComponentModel.CancelEventHandler(this.txtValA_Validating);
            // 
            // txtValB
            // 
            this.txtValB.Location = new System.Drawing.Point(101, 83);
            this.txtValB.Name = "txtValB";
            this.txtValB.Size = new System.Drawing.Size(100, 20);
            this.txtValB.TabIndex = 1;
            this.txtValB.TextChanged += new System.EventHandler(this.txtValB_TextChanged);
            this.txtValB.Validating += new System.ComponentModel.CancelEventHandler(this.txtValB_Validating);
            // 
            // txtValC
            // 
            this.txtValC.Location = new System.Drawing.Point(101, 142);
            this.txtValC.Name = "txtValC";
            this.txtValC.Size = new System.Drawing.Size(100, 20);
            this.txtValC.TabIndex = 2;
            this.txtValC.Validating += new System.ComponentModel.CancelEventHandler(this.txtValC_Validating);
            // 
            // lblValA
            // 
            this.lblValA.AutoSize = true;
            this.lblValA.Location = new System.Drawing.Point(24, 33);
            this.lblValA.Name = "lblValA";
            this.lblValA.Size = new System.Drawing.Size(56, 13);
            this.lblValA.TabIndex = 3;
            this.lblValA.Text = "Valor de A";
            // 
            // lblValB
            // 
            this.lblValB.AutoSize = true;
            this.lblValB.Location = new System.Drawing.Point(24, 83);
            this.lblValB.Name = "lblValB";
            this.lblValB.Size = new System.Drawing.Size(56, 13);
            this.lblValB.TabIndex = 4;
            this.lblValB.Text = "Valor de B";
            // 
            // lblValC
            // 
            this.lblValC.AutoSize = true;
            this.lblValC.Location = new System.Drawing.Point(24, 145);
            this.lblValC.Name = "lblValC";
            this.lblValC.Size = new System.Drawing.Size(56, 13);
            this.lblValC.TabIndex = 5;
            this.lblValC.Text = "Valor de C";
            // 
            // btnExecuta
            // 
            this.btnExecuta.Location = new System.Drawing.Point(60, 263);
            this.btnExecuta.Name = "btnExecuta";
            this.btnExecuta.Size = new System.Drawing.Size(95, 35);
            this.btnExecuta.TabIndex = 6;
            this.btnExecuta.Text = "Executar";
            this.btnExecuta.UseVisualStyleBackColor = true;
            this.btnExecuta.Click += new System.EventHandler(this.btnExecuta_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(201, 263);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(95, 35);
            this.btnSair.TabIndex = 7;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // txtType
            // 
            this.txtType.Enabled = false;
            this.txtType.Location = new System.Drawing.Point(111, 205);
            this.txtType.Multiline = true;
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(105, 26);
            this.txtType.TabIndex = 8;
            // 
            // lblTipoTri
            // 
            this.lblTipoTri.AutoSize = true;
            this.lblTipoTri.Location = new System.Drawing.Point(12, 208);
            this.lblTipoTri.Name = "lblTipoTri";
            this.lblTipoTri.Size = new System.Drawing.Size(93, 13);
            this.lblTipoTri.TabIndex = 9;
            this.lblTipoTri.Text = "Tipo de Triângulo:";
            this.lblTipoTri.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(446, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(328, 274);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblTipoTri);
            this.Controls.Add(this.txtType);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnExecuta);
            this.Controls.Add(this.lblValC);
            this.Controls.Add(this.lblValB);
            this.Controls.Add(this.lblValA);
            this.Controls.Add(this.txtValC);
            this.Controls.Add(this.txtValB);
            this.Controls.Add(this.txtValA);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtValA;
        private System.Windows.Forms.TextBox txtValB;
        private System.Windows.Forms.TextBox txtValC;
        private System.Windows.Forms.Label lblValA;
        private System.Windows.Forms.Label lblValB;
        private System.Windows.Forms.Label lblValC;
        private System.Windows.Forms.Button btnExecuta;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.Label lblTipoTri;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}


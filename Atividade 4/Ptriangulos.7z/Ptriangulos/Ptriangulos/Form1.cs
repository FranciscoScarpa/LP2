﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulos
{
    public partial class Form1 : Form
    {
        double valorA, valorB, valorC;
        string TipoTriangulo;
        public Form1()
        {

            InitializeComponent();
        }

        private void txtValB_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtValB_Validating(object sender, CancelEventArgs e)
        {

            if (!double.TryParse(txtValB.Text, out valorB))
            {
                MessageBox.Show("Valor B inválido!");
                txtValB.Focus();
            }
        }

        private void txtValC_Validating(object sender, CancelEventArgs e)
        {

            if (!double.TryParse(txtValC.Text, out valorC))
            {
                MessageBox.Show("Valor C inválido!");
                txtValC.Focus();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnExecuta_Click(object sender, EventArgs e)
        {
            //  if ((valorA < (valorB + valorC) && (valorA > Math.ABS(valorB - valorC) && (valorB < (valorA + valorC) &&

            if ((valorA < (valorB + valorC) && valorA > (valorB - valorC) && valorB < (valorA + valorC) && valorB > (valorA - valorC) && valorC < (valorA + valorB) && valorC > (valorA - valorB)))
            {

                MessageBox.Show("Os valores são válido. Formam um triângulo!");


            }
            else
            {
                MessageBox.Show("Os valores não formam um triângulo!");
            }


            if (valorA == valorB && valorB == valorC)
            {

                TipoTriangulo = "Equilátero!";
                txtType.Text = TipoTriangulo;

            }
            else if (valorA == valorB && valorB != valorC)
            {

                TipoTriangulo = "Isósceles!";
                txtType.Text = TipoTriangulo;

            }
            else if (valorA != valorB && valorB != valorC)
            {

                TipoTriangulo = "Escaleno!";
                txtType.Text = TipoTriangulo;
            }
        }
        private void txtValA_Validating(object sender, CancelEventArgs e)
        {

            if (!double.TryParse(txtValA.Text, out valorA))
            {
                MessageBox.Show("Valor A inválido!");
                txtValA.Focus();
            }
        }

        private void txtValA_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }

        private void btnSair_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("Você realmente deseja sair ?",
                "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)

                Close();
        }

    }
}

